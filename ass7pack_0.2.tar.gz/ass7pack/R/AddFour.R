AddFour <-
function(n){
  x <- n+4
  return(x)
}
