is.funny <-
function(x){
  return(T)
}
